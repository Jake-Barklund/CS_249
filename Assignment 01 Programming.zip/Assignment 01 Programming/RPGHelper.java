package edu.barkluj.Assign01;

import java.util.Scanner;

public class RPGHelper {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter strength and wisdom:");
        int strengthvalue = input.nextInt();
        int wisdomvalue = input.nextInt();

        if(strengthvalue<=0 || wisdomvalue<=0){
            System.err.println("ERROR: Negative entry!");
        }
        else if(strengthvalue>=50 && wisdomvalue>=50){
            System.out.println("PALADIN!");
        }
        else if(strengthvalue>=50 && wisdomvalue<50){
            System.out.println("BARBARIAN!");
        }
        else if(strengthvalue<50 && wisdomvalue>=50){
            System.out.println("WIZARD!");
        }
        else if(strengthvalue<50 && wisdomvalue<50){
            System.out.println("HOBO!");
        }
    }
}
