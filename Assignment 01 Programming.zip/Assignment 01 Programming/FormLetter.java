package edu.barkluj.Assign01;
import java.util.Scanner;

public class FormLetter {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter first name:");
        String firstname = input.next();

        System.out.println("Enter whole number:");
        int moneyinput = input.nextInt();

        System.out.println("Congratulations " + firstname + "!");
        System.out.println("You may have won $" + moneyinput + "!");
    }
}
