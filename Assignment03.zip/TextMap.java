package edu.barkluj.Assign03;

public class TextMap {
    private int rowCount, colCount;
    private char defChar;
    private char[][] charArray;

    public TextMap(int rowCnt, int colCnt, char defaultChar){
        rowCount = rowCnt;
        colCount = colCnt;
        defChar = defaultChar;
        charArray = new char[rowCnt][colCnt];
        for(int i=0; i<rowCnt; i++){
            for(int j=0; j<colCnt; j++){
                charArray[i][j] = defaultChar;
            }
        }
    }
    public int getRowCount(){
       return rowCount;
    }
    public int getColCount(){
        return colCount;
    }
    public boolean isValidPosition(MapCoord coord){
        if(coord.getRow()<getRowCount() || coord.getColumn()<getColCount() || coord.getRow()>=0 || coord.getColumn()>=0){
            return true;
        }
        else{
            return false;
        }
    }
    public char getPos(MapCoord coord){
        if(isValidPosition(coord)){
            return charArray[coord.getRow()][coord.getColumn()];
        }
        else{
            return defChar;
        }
    }
    public boolean setPos(MapCoord coord, char c){
        if(isValidPosition(coord)){
            charArray[coord.getRow()][coord.getColumn()] = c;
            return true;
        }
        else{
            return false;
        }
    }
    public String toString(){
        StringBuilder mapData = new StringBuilder();
        for(int i=0; i<getRowCount(); i++){
            for(int j=0; j<getColCount(); j++) {
                mapData.append(charArray[i][j]);
            }
            mapData.append("\n");
        }

        return mapData.toString();
    }
}
