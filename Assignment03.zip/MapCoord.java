package edu.barkluj.Assign03;

public class MapCoord {

    private int row;
    private int column;

    public MapCoord(int r, int c){
        row = r;
        column = c;
    }
    public int getRow(){
        return row;
    }
    public int getColumn(){
        return column;
    }
    public String toString(){
        String coordinate = "(" + getRow() + "," + getColumn() + ")";
        return coordinate;
    }
}
