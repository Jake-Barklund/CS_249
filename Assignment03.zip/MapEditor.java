package edu.barkluj.Assign03;

import java.util.Scanner;

public class MapEditor {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter rows, columns, and default character:");
        int row = scanner.nextInt();
        int col = scanner.nextInt();
        char defChar = scanner.next().charAt(0);

        MapCoord myCoord = new MapCoord(row, col);
        myCoord.toString();

        TextMap myMap = new TextMap(row, col, defChar);
        System.out.println(myMap.toString());

        do{
            System.out.println("Enter rows, columns, and character:");
            int coordRow = scanner.nextInt();
            int coordCol = scanner.nextInt();
            char coordChar = scanner.next().charAt(0);

            MapCoord updateCoord = new MapCoord(coordRow, coordCol);
            updateCoord.toString();

            myMap.setPos(updateCoord, coordChar);

            System.out.println(myMap);
        }
        while(myMap.isValidPosition(myCoord));
    }
}
