package edu.barkluj.Assign02;

import java.util.Scanner;

public class TitleProgram {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter message:");
        String message = scanner.nextLine();
        System.out.println(FancyTitle.createFancyTitle(message, '*'));
        System.out.println(FancyTitle.createFancyTitle(message, '$'));
    }
}