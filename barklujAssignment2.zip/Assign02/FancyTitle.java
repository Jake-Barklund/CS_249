package edu.barkluj.Assign02;

public class FancyTitle{
    public static int countFibSteps(int maxVal){
        int currentNum = 1, previousNum = 1, numOfSteps = 0, newVal = 1;
        while(currentNum < maxVal) {
            newVal = currentNum + previousNum;
            previousNum = currentNum;
            currentNum = newVal;
            numOfSteps++;
        }
        return numOfSteps;
    }
    public static String repeatChar(char c, int cnt){
        String count = new String();
        for(int i=0; i<cnt; i++){
            count += String.valueOf(c);
        }
        return count;
    }
    public static String[] makeFibStringList(char c, int levels){
        String[] stringArray = new String[levels];
        String str = new String();
        int newVal = 1, currentVal = 1, previousVal = 1;
        for(int i=0; i<levels; i++){
            str = repeatChar(c, newVal);
            stringArray[i] = str;
            newVal = currentVal + previousVal;
            previousVal = currentVal;
            currentVal = newVal;
        }

        return stringArray;
    }
    public static String makeFilledCenterString(String border, int desiredLen){
        String str = new String();
        String spaces = new String();
        int numSpaces = 0, borderLength = 0;

        borderLength = border.length();
        numSpaces = desiredLen - 2 * (borderLength);
        spaces = repeatChar(' ', numSpaces);
        str = border + spaces + border;

        return str;
    }
    public static String[] makeFooter(char c, int desiredLen){
        String[] stringArray = new String[desiredLen];
        int numLevels = countFibSteps(desiredLen/2);
        stringArray = makeFibStringList(c, numLevels);
        for(int i=0; i<numLevels; i++){
            stringArray[i] = makeFilledCenterString(stringArray[i],desiredLen);
        }

        return stringArray;
    }
    public static String createFancyTitle(String message, char c){
        int desiredLength = message.length() + 4;
        StringBuilder stringBuilder = new StringBuilder();
        String[] footerArray= makeFooter(c, desiredLength);
        String[] headerArray = new String[footerArray.length];
        String output = new String(), header = new String(), footer = new String(), messageString = new String(), borderString = new String();

        borderString = repeatChar(c, desiredLength);
        stringBuilder.append(borderString + "\n");
        for(int i=footerArray.length-1; i>=0; i--) {
            headerArray[i] = footerArray[i];
            stringBuilder.append(headerArray[i] + "\n");
        }
        messageString = c + " " + message + " " + c;
        stringBuilder.append(messageString + "\n");
        for(int i=0; i<footerArray.length; i++){
            stringBuilder.append(footerArray[i] + "\n");
        }
        stringBuilder.append(borderString + "\n");

        return stringBuilder.toString();
    }
}
